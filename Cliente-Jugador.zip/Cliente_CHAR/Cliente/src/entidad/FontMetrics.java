package entidad;

public class FontMetrics {

}
